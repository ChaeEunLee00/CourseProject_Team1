import styled from "@emotion/styled";
import { PictureOutlined } from "@ant-design/icons";
import { useRef, useState } from "react";
import axios from "axios";

const Container = styled.div`
    display: flex;
    flex-direction: column;
`;

const Title = styled.div`
    width: 600px;
    height: 50px;
    font-size: 35px;
    font-weight: bold;
`;

const ImageContainer = styled.div`
    border: 1px solid #D8D8D8;
    height: 100px;
    width: 100px;
    overflow: hidden;
    cursor: pointer;
    display: flex;
    justify-content: center;
    align-items: center;
`;

const PlaceImage = styled.img`
    width: 100%;
    height: 100%;
    object-fit: cover;
`;

const PlaceImageIcon = styled(PictureOutlined)`
    font-size: 50px;
`;

const HiddenPictureInput = styled.input`
    display: none;
`;

const Content = styled.input`
    width: 600px;
    height: 400px;
    border: 1px solid #D8D8D8;
    box-sizing: border-box;
    padding-top: 0px;
    line-height: 1;
`;

export const AddPost = () => {
    const fileInputRef = useRef<HTMLInputElement | null>(null);
    const [imageUrl, setImageUrl] = useState<string | null>(null);
    const [placeImage, setPlaceImage] = useState(null);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files && e.target.files[0];

        if (file) {
            handleFileChange(file);

            const imageUrl = URL.createObjectURL(file);
            setImageUrl(imageUrl);
        }
    };

    const handleFileChange = (file) => {
        setPlaceImage(file);
    };

    const handleButtonClick = () => {
        fileInputRef.current?.click();
    };
    
    

    const handleAddPost = async () => {
        try {
            // Post 정보를 서버로 전송
            // 작성한 사용자 객체
            // 첨부한 이미지와 글
            // 해시태그
            const formData = new FormData();
            if (placeImage) {
                formData.append("placeImage", placeImage);
            }

            const response = await axios.post("/api/post", formData, {
                headers: {
                    "Content-Type" : "multipart/form-data",
                },
            });

            console.log(response.data);
        } catch (error) {
            console.log("post 실패", error);
        }
    };
    return (
        <Container>
            <Title>Create a Post</Title>
            <ImageContainer onClick={handleButtonClick}>
                {imageUrl ? (
                    <PlaceImage src={imageUrl} alt="place" />
                ) : (
                    <PlaceImageIcon />
                )}
                <HiddenPictureInput
                    type="file"
                    accept="image/*"
                    ref={fileInputRef}
                    onChange={handleInputChange}
                />
            </ImageContainer>
            <Content type="text"></Content>
        </Container>
    )
}