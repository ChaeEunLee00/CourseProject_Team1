import styled from "@emotion/styled";

const Container = styled.div``;

export const CreatePost = () => {
    return (
        <Container></Container>
    );
}