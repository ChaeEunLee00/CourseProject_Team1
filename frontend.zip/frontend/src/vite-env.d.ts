// TypeScript 환경에서 필요한 타입 선언을 관리하는 파일이다. 주로 라이브러리에서 제공하지 않는 타입이나 커스텀 타입을 선언하는 데 사용된다.
/// <reference types="vite/client" />
