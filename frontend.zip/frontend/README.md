# CourseProject_Team1_frontend
to run the code; (in terminal)
1. npm install
2. npm run dev
   

